package etec.sp.gov.br.atividadeavaliativa;

import java.util.Date;

public class Poupanca extends Conta {
    private Date aniversario;

    public Poupanca(Integer numero, String titular, Double saldo, Date aniversario) {
        super(numero, titular, saldo);
        this.aniversario = aniversario;
    }

    public Date getAniversario() {
        return aniversario;
    }

    public void setAniversario(Date aniversario) {
        this.aniversario = aniversario;
    }
}