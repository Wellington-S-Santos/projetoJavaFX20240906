package etec.sp.gov.br.atividadeavaliativa;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HelloController {
    @FXML
    private Button btnRegistrar;
    @FXML
    private Button btnDeposito;
    @FXML
    private Button btnSacar;
    @FXML
    private Button btnPesquisar;
    @FXML
    private RadioButton rbtCorrente;
    @FXML
    private RadioButton rbtPoupanca;
    @FXML
    private RadioButton rbtEspecial;
    @FXML
    private TextField txtNConta;
    @FXML
    private TextField txtNTitular;
    @FXML
    private TextField txtLimite;
    @FXML
    private TextField txtDVencimento;
    @FXML
    private TextField txtValor;
    @FXML
    private TextField txtPesquisar;
    @FXML
    private Label lbSaldo;
    @FXML
    private TextArea txtAreaDados;

    private Conta conta;
    private Especial especial;
    private Poupanca poupanca;
    private List<Conta> listaContas = new ArrayList<>();

    @FXML
    protected void onSelecionarTipo(){
        if (rbtCorrente.isSelected()){
            txtLimite.setDisable(true);
            txtDVencimento.setDisable(true);
        } else if (rbtEspecial.isSelected()) {
            txtLimite.setDisable(false);
            txtDVencimento.setDisable(true);
        }else {
            txtLimite.setDisable(true);
            txtDVencimento.setDisable(false);
        }
    }
    @FXML
    protected void onClickRegistrar(){

        if (rbtCorrente.isSelected()){
            conta = new Conta(Integer.parseInt(txtNConta.getText()),txtNTitular.getText(),0.0);

            listaContas.add(conta);
            txtAreaDados.setText(listaContas.toString());
            limparCampos();
        } else if (rbtEspecial.isSelected()) {
             especial= new Especial(Integer.parseInt(txtNConta.getText()),txtNTitular.getText(), 0.0,Double.parseDouble(txtLimite.getText()));
             
            listaContas.add(especial);
            txtAreaDados.setText(listaContas.toString());
            limparCampos();
        } else  {
            SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");

            try {
                String dataString;
                Date data = formato.parse(txtDVencimento.getText());
                poupanca = new Poupanca(Integer.parseInt(txtNConta.getText()),txtNTitular.getText(), 0.0,data );
                listaContas.add(especial);
                txtAreaDados.setText(listaContas.toString());
                limparCampos();
            } catch (ParseException e) {
                System.out.println("Erro ao converter a data: " + e.getMessage());
            }

            
        }

    }
    private void limparCampos (){
        txtNConta.setText("");
        txtNTitular.setText("");
        txtLimite.setText(" ");
        txtDVencimento.setText("");
        txtValor.setText("");
        rbtCorrente.setSelected(false);
        rbtEspecial.setSelected(false);
        rbtPoupanca.setSelected(false);
    }





}